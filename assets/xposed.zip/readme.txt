
 .ttf - Original, Free Truetype fonts!

 For more original fonts by .ttf, check out
 http://members.xoom.com/freefont/

 - This font is freeware, not public domain.
   You may not distribute, change, or upload the
   fonts onto any site, CD or any other means.

 - For more information, see our site at
   http://members.xoom.com/freefont/