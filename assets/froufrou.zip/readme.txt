  
   -------------------------------------
   .ttf               www.ttfnet.cjb.net
   ------------------------------------- 

   The attached font is an original font
   from .ttf, and is freeware.

   You are free to distribute this font
   but keep this readme file with it &
   do not change the font in any way.

   Visit .ttf for more original fonts,
   and many more distressed, typewriter,
   smooth and handwriting fonts.

   -------------------------------------
   How to install the font
   -------------------------------------
  
1  Extract the enclosed font to any
   temporary folder.

2  Go to the Fonts section of Control
   Panel (Start > Settings > Control
   Panel > Fonts) and choose File >
   Install New Font. In the window that
   comes up, find the folder where you
   extracted the font. Select it and
   click OK. The font is now installed,
   and can be used with all Windows
   applications.

   ------------------------------------
   .ttf         Copyright (c) 1998-1999
   ------------------------------------
